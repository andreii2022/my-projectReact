import React from 'react';

const Footer = () => {
    return (
        <footer>
            footer
        </footer>
    );
};

export default Footer;