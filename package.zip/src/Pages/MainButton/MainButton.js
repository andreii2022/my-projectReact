import React from 'react';

const MainButton = (props) => {
    return (
        
    <button className={props.styleClass}>
        secure my spot now!
    </button>     
    
    );
};

export default MainButton;