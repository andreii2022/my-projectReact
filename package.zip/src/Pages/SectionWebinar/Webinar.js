import React from 'react';
import icons from '../../images/sprites/sprite.svg'

const Webinar = () => {
    return (
        <div>

            <div className='colums'>
                <div className='container'>
                    <div className='columns__title'>
                        <div className='colums__title-first'>Let's discover more</div>
                        <div className='colums__title-second'>After This Webinar You Will Be Able To…</div>
                    </div>
                    <div className='columns__row'>
                        <div className='columns__column'>
                            <div className='columns__icon-baks'>
                            <svg>
                            <use href={`${icons}#baks`}></use>
                            </svg>
                                <p className='columns__text-baks'>Turn your followers into paying customers without hassle and overworking 24/7.</p>
                            </div>
                        </div>
                        <div className='columns__column'>
                            <div className='columns__icon-square'>
                            <svg>
                            <use href={`${icons}#Squares`}></use>
                            </svg>
                                <p className='columns__text-square'>Generate Sales around the clock with our top-notch scripts.</p>
                            </div>
                        </div>
                        <div className='columns__column'>
                            <div className='columns__icon-wallet'>
                            <svg>
                            <use href={`${icons}#wallet`}></use>
                            </svg>
                                <p className='columns__text-wallet'>Earn 6-figure with online courses, coaching sessions, fitness classes.</p>
                            </div>
                        </div>
                        <div className='columns__column'>
                            <div className='columns__icon-phone'>
                            <svg>
                            <use href={`${icons}#phone`}></use>
                            </svg>
                                <p className='columns__text-phone'>Launch Your Own App for IOS and Android in 7 days without coding</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    );
};

export default Webinar;